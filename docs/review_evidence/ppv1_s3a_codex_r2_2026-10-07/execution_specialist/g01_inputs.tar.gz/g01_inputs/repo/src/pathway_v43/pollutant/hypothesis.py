"""ReactionHypothesis — 先定义反应假设,再提交事件(实施书 §5.2,S1)。

- 参与物 participants[]:每项 state_ref + side + role + coefficient;
  已知系数必须是正有限有理数(Fraction);未知系数 null+unknown;
  禁止 known+null、零、负数或非有限数(H02 输入契约,fail-closed);
- 重复参与物不用集合去重丢系数:同侧、同物种、同角色且**调用方明确
  声明为并列计量贡献**(parallel_contribution=True)的重复项可求和,
  保留原条目与归并轨迹;含义/系数未知则保留歧义(ambiguous 标记),
  不猜(H03);
- 同一已知裂解反应的共同产物属于一个假设/事件;未提供副产物或共底物
  可保留 partial 假设,但完整配平必须 unknown;
- 模型新输出用 proposals[](每项一条独立假设);不同假设是备选解释,
  不据此断言互斥;
- 历史 novel 平列表语义不明确 → legacy_relationship_unspecified,
  不静默拆成单产物反应,也不重解释为已证实共同产物(A04);
- step_scope=multistep_summary 保留为汇总边,不冒充净酶反应;
- hypothesis_id 来自冻结反应语义(参与物规范化 + 转化引用 + 来源组
  键);无法确认等价的来源不强制合并(不同来源组键 → 不同 id)。

R4 回修(R3-08,ppv1-hypothesis-4):
- **requirements 完整构造校验**:元素必须是 dict(Requirement 对象
  不受支持 ⇒ HypothesisContractError(kind=requirement_object_not_
  supported),绝无裸 TypeError);level 必填且 ∈ {essential,
  preference};value 必填;key 必须是已知条件键;区间值 lo ≤ hi;
  source_refs/绑定字段类型校验(共用 path_context.
  validate_requirement_dict)。
- **外来绑定结构化拒绝(R3-06)**:requirements 预填**外来**
  introduced_phase_id/introduced_edge/scenario_ref(属于另一旧边)
  ⇒ HypothesisContractError(kind=foreign_requirement_binding);
  合法自绑定(introduced_edge == 本假设 id,重放上下文绑定过的要求
  集)允许。绑定字段是**上下文层出处,不进假设身份**——存储载荷中
  一律归零(同语义的未绑定/自绑定构造 ⇒ 同 id 且同 payload)。
- **深拷贝**:requirements dicts 构造期深拷贝,caller-owned dict
  后续修改不影响假设内容/身份。
- **排序幂等(R3-08 下半套)**:canonical_hypothesis_payload——
  requirements 按每条 canonical_json 排序、assumptions/dependency_
  refs 排序,其余字段原样;to_dict 输出此规范形;hypothesis_id 的
  身份哈希也基于此规范形(同语义不同顺序 ⇒ 同 id 且同 payload)。
- **可重推导身份**:recompute_hypothesis_id 从载荷(不含
  hypothesis_id 字段)按构造期同算法重推导 id(存储线 submit 复核
  "提供的 id 与载荷一致");payload 增加 origin_group_key 字段
  (身份输入完整可重推导;版本已升 -4,旧 -3 载荷由版本门拒绝)。

R5 回修(R4-02,ppv1-hypothesis-5):
- **requirements 嵌套冻结**:存储侧 requirement dict 为冻结映射、
  区间 value 递归冻结(path_context 的 _FrozenValueDict/_freeze)——
  对自身科学前提的就地修改(setitem/update/`|=`/嵌套 value 改写)
  立即 TypeError,不再"改科学前提而保留 hypothesis_id"(复审
  hypothesis_live_nested_mutation 反例);to_dict 输出普通可变副本
  (存储/哈希路径不变)。
- **入口身份复算接线(R4-02)**:store 的 put_hypothesis/submit/
  重放调用 recompute_hypothesis_id 复核"载荷 ID == 内容重推导 ID"
  (见 store v5)——对象级冻结与入口复算双层。
"""

from __future__ import annotations

import copy
import math
from dataclasses import dataclass, field
from fractions import Fraction

from ..domain.models import canonical_json, stable_id
from .path_context import (
    REQUIREMENT_BINDING_FIELDS,
    ConditionContractError as _ConditionContractError,
    Requirement as _Requirement,
    _FrozenValueDict as _FrozenValueDict,
    _freeze as _freeze_value,
    _thaw as _thaw_value,
    validate_requirement_dict as _validate_requirement_dict,
)
from .profile import PPV1_HYPOTHESIS_SCHEMA_VERSION

PPV1_HYPOTHESIS_SUPPORTED_VERSIONS = (PPV1_HYPOTHESIS_SCHEMA_VERSION,)

PARTICIPANT_SIDE_REACTANT = "reactant"
PARTICIPANT_SIDE_PRODUCT = "product"
PARTICIPANT_SIDES = frozenset({PARTICIPANT_SIDE_REACTANT,
                               PARTICIPANT_SIDE_PRODUCT})

PARTICIPANT_ROLE_PRIMARY_SUBSTRATE = "primary_substrate"
PARTICIPANT_ROLE_COSUBSTRATE = "cosubstrate"
PARTICIPANT_ROLE_PRINCIPAL_PRODUCT = "principal_product"
PARTICIPANT_ROLE_COPRODUCT = "coproduct"
PARTICIPANT_ROLE_UNKNOWN = "unknown"
PARTICIPANT_ROLES = frozenset({
    PARTICIPANT_ROLE_PRIMARY_SUBSTRATE, PARTICIPANT_ROLE_COSUBSTRATE,
    PARTICIPANT_ROLE_PRINCIPAL_PRODUCT, PARTICIPANT_ROLE_COPRODUCT,
    PARTICIPANT_ROLE_UNKNOWN,
})

COEFFICIENT_KNOWN = "known"
COEFFICIENT_UNKNOWN = "unknown"

PARTICIPANT_LIST_SOURCE_COMPLETE = "source_complete"
PARTICIPANT_LIST_DECLARED_COMPLETE = "declared_complete"
PARTICIPANT_LIST_PARTIAL = "partial"
PARTICIPANT_LIST_UNKNOWN = "unknown"
PARTICIPANT_LIST_STATUSES = frozenset({
    PARTICIPANT_LIST_SOURCE_COMPLETE, PARTICIPANT_LIST_DECLARED_COMPLETE,
    PARTICIPANT_LIST_PARTIAL, PARTICIPANT_LIST_UNKNOWN,
})

STEP_SCOPE_NET_REACTION = "net_reaction"
STEP_SCOPE_ELEMENTARY_STEP = "elementary_step"
STEP_SCOPE_MULTISTEP_SUMMARY = "multistep_summary"
STEP_SCOPE_UNKNOWN = "unknown"
STEP_SCOPES = frozenset({
    STEP_SCOPE_NET_REACTION, STEP_SCOPE_ELEMENTARY_STEP,
    STEP_SCOPE_MULTISTEP_SUMMARY, STEP_SCOPE_UNKNOWN,
})

LEGACY_RELATIONSHIP_UNSPECIFIED = "legacy_relationship_unspecified"


class HypothesisContractError(RuntimeError):
    """参与物/假设输入契约违反(结构化 fail-closed,含定位信息)。"""

    def __init__(self, message: str, detail: dict | None = None):
        super().__init__(message)
        self.detail = detail or {}


def _freeze_requirement_dict(req: dict) -> dict:
    """R4-02:requirement dict 的存储侧冻结形(顶层冻结映射 + 嵌套
    value 递归冻结)。对科学前提的就地修改立即 TypeError;to_dict/
    载荷路径经 _thaw_requirement_dict 转回普通可变副本。"""
    return _FrozenValueDict({k: _freeze_value(v) for k, v in req.items()})


def _thaw_requirement_dict(req: dict) -> dict:
    return _thaw_value(dict(req))


def parse_coefficient(value) -> Fraction:
    """系数 → 正有限 Fraction(H02:零/负/非有限/known+null 拒绝)。"""
    if value is None:
        raise HypothesisContractError(
            "系数为 null:未知系数须标 coefficient_status=unknown,不得 "
            "以 known+null 表示", {"kind": "known_coefficient_null"})
    if isinstance(value, bool):
        raise HypothesisContractError(
            f"系数非法(bool):{value!r}", {"kind": "invalid_coefficient_type",
                                        "value": repr(value)})
    if isinstance(value, Fraction):
        frac = value
    elif isinstance(value, float):
        if not math.isfinite(value):
            raise HypothesisContractError(
                f"系数非有限数值:{value!r}", {"kind": "non_finite_coefficient",
                                             "value": repr(value)})
        frac = Fraction(str(value))
    elif isinstance(value, int):
        frac = Fraction(value)
    elif isinstance(value, str):
        try:
            frac = Fraction(value)
        except (ValueError, ZeroDivisionError) as exc:
            raise HypothesisContractError(
                f"系数无法解析为有理数:{value!r}",
                {"kind": "invalid_coefficient", "value": value,
                 "error": str(exc)}) from exc
    else:
        raise HypothesisContractError(
            f"系数类型非法:{type(value).__name__}",
            {"kind": "invalid_coefficient_type", "value": repr(value)})
    if frac <= 0:
        raise HypothesisContractError(
            f"系数必须为正:{value!r}(零/负数拒绝;该拒绝是输入表示层"
            "契约,不宣称反应本身化学不可能)",
            {"kind": "non_positive_coefficient", "value": repr(value)})
    return frac


def coefficient_to_json(frac: Fraction | None) -> str | None:
    return str(frac) if frac is not None else None


def coefficient_from_json(value: str | None) -> Fraction | None:
    return Fraction(value) if value is not None else None


@dataclass
class Participant:
    """参与物条目(计量层;来源支持在 provenance 层,不混入)。

    构造即校验(H02 fail-closed):coefficient 接受 int/float/str/Fraction,
    一律归一为正有限 Fraction;known+null、零/负/非有限、unknown+数值
    均拒绝。系数未知用 coefficient=None + status=unknown。
    """

    state_ref: str                     # ChemicalState.state_id
    side: str                          # reactant | product
    role: str                          # §5.2 角色枚举
    coefficient: Fraction | None       # 正有理数;None = 未知
    coefficient_status: str            # known | unknown
    parallel_contribution: bool = False  # 调用方明确声明:并列计量贡献
    merged_from: list[str] = field(default_factory=list)  # 归并轨迹(H03)
    entry_id: str = ""                 # 原条目指纹(归并前)

    def __post_init__(self) -> None:
        if self.coefficient_status == COEFFICIENT_UNKNOWN:
            if self.coefficient is not None:
                raise HypothesisContractError(
                    "unknown 系数必须为 null(不能携带数值)",
                    {"kind": "unknown_coefficient_with_value",
                     "state_ref": self.state_ref})
            return
        if self.coefficient_status != COEFFICIENT_KNOWN:
            raise HypothesisContractError(
                f"coefficient_status 非法:{self.coefficient_status!r}",
                {"kind": "invalid_coefficient_status",
                 "coefficient_status": self.coefficient_status})
        if self.coefficient is None:
            raise HypothesisContractError(
                "known 系数不能为 null(known+null 禁止)",
                {"kind": "known_coefficient_null",
                 "state_ref": self.state_ref})
        if not isinstance(self.coefficient, Fraction):
            # int/float/str → Fraction(非法值在 parse_coefficient 拒绝)
            self.coefficient = parse_coefficient(self.coefficient)
        else:
            parse_coefficient(self.coefficient)  # 正性/有限复核

    def to_dict(self) -> dict:
        return {
            "state_ref": self.state_ref, "side": self.side,
            "role": self.role, "coefficient": coefficient_to_json(
                self.coefficient),
            "coefficient_status": self.coefficient_status,
            "parallel_contribution": self.parallel_contribution,
            "merged_from": list(self.merged_from),
            "entry_id": self.entry_id,
        }

    @classmethod
    def from_dict(cls, d: dict) -> "Participant":
        return cls(
            state_ref=d["state_ref"], side=d["side"], role=d["role"],
            coefficient=coefficient_from_json(d.get("coefficient")),
            coefficient_status=d["coefficient_status"],
            parallel_contribution=bool(d.get("parallel_contribution", False)),
            merged_from=list(d.get("merged_from", [])),
            entry_id=d.get("entry_id", ""),
        )


def _entry_fingerprint(p: Participant) -> str:
    return stable_id("pentry", p.state_ref, p.side, p.role,
                     coefficient_to_json(p.coefficient) or "null",
                     str(p.parallel_contribution))


def _validate_participant(p: Participant, index: int) -> None:
    where = {"participant_index": index, "state_ref": p.state_ref}
    if p.side not in PARTICIPANT_SIDES:
        raise HypothesisContractError(
            f"参与物 side 非法:{p.side!r}", {**where, "side": p.side})
    if p.role not in PARTICIPANT_ROLES:
        raise HypothesisContractError(
            f"参与物 role 非法:{p.role!r}", {**where, "role": p.role})
    if p.coefficient_status == COEFFICIENT_KNOWN:
        if p.coefficient is None:
            raise HypothesisContractError(
                "known 系数不能为 null(known+null 禁止)",
                {**where, "kind": "known_coefficient_null"})
        parse_coefficient(p.coefficient)  # 正性/有限复核
    elif p.coefficient_status == COEFFICIENT_UNKNOWN:
        if p.coefficient is not None:
            raise HypothesisContractError(
                "unknown 系数必须为 null(不能携带数值)",
                {**where, "kind": "unknown_coefficient_with_value"})
    else:
        raise HypothesisContractError(
            f"coefficient_status 非法:{p.coefficient_status!r}",
            {**where, "coefficient_status": p.coefficient_status})


def normalize_participants(
    participants: list[Participant],
) -> tuple[list[Participant], bool]:
    """并列计量归并(§17.4 H03;保守、显式、可回溯)。

    规则:
    - 同 (side, state_ref, role) 且**全部**条目 parallel_contribution=True
      且系数 known → 求和为一个条目,merged_from 保留原条目指纹;
    - 同 (side, state_ref, role) 但声明不全/系数 unknown/角色 unknown
      → 保留重复条目并返回 ambiguous=True(保留歧义,不猜);
    - 来源重复引用不得重复加计量:同一来源的重复引用应在导入层只产生
      一条参与物(本函数不做来源去重 —— 那是 provenance 层的职责)。

    返回 (归并后列表, 是否存在保留歧义的重复)。
    """
    for i, p in enumerate(participants):
        _validate_participant(p, i)
    groups: dict[tuple[str, str, str], list[Participant]] = {}
    order: list[tuple[str, str, str]] = []
    for p in participants:
        if not p.entry_id:
            p.entry_id = _entry_fingerprint(p)
        key = (p.side, p.state_ref, p.role)
        if key not in groups:
            groups[key] = []
            order.append(key)
        groups[key].append(p)
    out: list[Participant] = []
    ambiguous = False
    for key in order:
        entries = groups[key]
        mergeable = (
            len(entries) > 1
            and all(e.parallel_contribution and e.role != PARTICIPANT_ROLE_UNKNOWN
                    for e in entries)
            and all(e.coefficient is not None for e in entries)
        )
        if mergeable:
            merged_coeff = sum(
                (e.coefficient for e in entries), Fraction(0))
            merged = Participant(
                state_ref=entries[0].state_ref, side=entries[0].side,
                role=entries[0].role, coefficient=merged_coeff,
                coefficient_status=COEFFICIENT_KNOWN,
                parallel_contribution=True,
                merged_from=[e.entry_id for e in entries],
                entry_id=stable_id("pmerged", *[e.entry_id for e in entries]),
            )
            out.append(merged)
        else:
            if len(entries) > 1:
                ambiguous = True  # 保留歧义,不静默去重/求和
            out.extend(entries)
    return out, ambiguous


@dataclass
class ReactionHypothesis:
    """反应假设(§5.2 全字段;参与物经 normalize 后入账)。

    R3-08:requirements 为**规范形深拷贝**(校验通过、绑定字段归零、
    按每条 canonical_json 排序);to_dict 输出 canonical_hypothesis_
    payload 规范形——同语义不同顺序 ⇒ 同 id 且同 payload。载荷含
    origin_group_key(身份输入完整,可 recompute_hypothesis_id 重推导)。
    """

    hypothesis_id: str
    parent_path_id: str
    substrate_state_ref: str
    participants: list[Participant]
    participant_list_status: str
    step_scope: str
    transformation_ref: str = ""
    transformation_signature_status: str = "unknown"  # verified|unknown|…
    step_scope_evidence_refs: list[str] = field(default_factory=list)
    provenance_refs: list[str] = field(default_factory=list)
    support_group_refs: list[str] = field(default_factory=list)
    requirements: list[dict] = field(default_factory=list)
    assumptions: list[str] = field(default_factory=list)
    dependency_refs: list[str] = field(default_factory=list)
    audit_ref: str = ""
    model_decision_ref: str = ""
    legacy_relationship_status: str = ""   # A04:legacy 平列表挂牌
    ambiguous_participants: bool = False   # H03:保留歧义标记
    origin_group_key: str = ""             # R3-08:入载荷,身份可重推导
    schema_version: str = PPV1_HYPOTHESIS_SCHEMA_VERSION

    def to_dict(self) -> dict:
        """规范形载荷(canonical_hypothesis_payload:requirements/
        assumptions/dependency_refs 排序归一,其余原样;R4-02:
        requirements 冻结存储形在此转回普通可变副本)。"""
        return canonical_hypothesis_payload({
            "schema_version": self.schema_version,
            "hypothesis_id": self.hypothesis_id,
            "parent_path_id": self.parent_path_id,
            "substrate_state_ref": self.substrate_state_ref,
            "participants": [p.to_dict() for p in self.participants],
            "participant_list_status": self.participant_list_status,
            "step_scope": self.step_scope,
            "transformation_ref": self.transformation_ref,
            "transformation_signature_status": (
                self.transformation_signature_status),
            "step_scope_evidence_refs": list(self.step_scope_evidence_refs),
            "provenance_refs": list(self.provenance_refs),
            "support_group_refs": list(self.support_group_refs),
            "requirements": [_thaw_requirement_dict(r)
                             for r in self.requirements],
            "assumptions": list(self.assumptions),
            "dependency_refs": list(self.dependency_refs),
            "audit_ref": self.audit_ref,
            "model_decision_ref": self.model_decision_ref,
            "legacy_relationship_status": self.legacy_relationship_status,
            "ambiguous_participants": self.ambiguous_participants,
            "origin_group_key": self.origin_group_key,
        })

    @classmethod
    def from_dict(cls, d: dict) -> "ReactionHypothesis":
        version = d.get("schema_version")
        if version not in PPV1_HYPOTHESIS_SUPPORTED_VERSIONS:
            raise HypothesisContractError(
                f"ReactionHypothesis schema 版本未知:{version!r}(支持 "
                f"{list(PPV1_HYPOTHESIS_SUPPORTED_VERSIONS)};fail-closed)",
                {"schema_version": version})
        raw_requirements = list(d.get("requirements", []))
        for i, raw in enumerate(raw_requirements):
            if not isinstance(raw, dict):
                raise HypothesisContractError(
                    f"假设要求必须是 dict:{type(raw).__name__}",
                    {"kind": "requirement_object_not_supported",
                     "requirement_index": i})
            try:
                _validate_requirement_dict(
                    raw, where={"requirement_index": i})
            except _ConditionContractError as exc:
                raise HypothesisContractError(
                    str(exc), dict(exc.detail)) from exc
        return cls(
            hypothesis_id=d["hypothesis_id"],
            parent_path_id=d["parent_path_id"],
            substrate_state_ref=d["substrate_state_ref"],
            participants=[Participant.from_dict(p)
                          for p in d["participants"]],
            participant_list_status=d["participant_list_status"],
            step_scope=d["step_scope"],
            transformation_ref=d.get("transformation_ref", ""),
            transformation_signature_status=d.get(
                "transformation_signature_status", "unknown"),
            step_scope_evidence_refs=list(
                d.get("step_scope_evidence_refs", [])),
            provenance_refs=list(d.get("provenance_refs", [])),
            support_group_refs=list(d.get("support_group_refs", [])),
            requirements=[_freeze_requirement_dict(r)
                          for r in raw_requirements],
            assumptions=list(d.get("assumptions", [])),
            dependency_refs=list(d.get("dependency_refs", [])),
            audit_ref=d.get("audit_ref", ""),
            model_decision_ref=d.get("model_decision_ref", ""),
            legacy_relationship_status=d.get(
                "legacy_relationship_status", ""),
            ambiguous_participants=bool(d.get("ambiguous_participants", False)),
            origin_group_key=d.get("origin_group_key", ""),
            schema_version=version,
        )


def _requirement_identity_signature(raw: dict) -> str:
    """单条要求的身份签名(R3-08:与构造期同口径)。

    Requirement 规范形(value_basis 推断、字段补全)+ **绑定字段归零**
    ——introduced_* 是上下文层出处,不进假设身份:同语义的未绑定
    构造与自绑定重放 ⇒ 同 id(这是"合法自绑定允许"的前提);外来
    绑定的拒绝在外层按 introduced_edge ≠ 本假设 id 判定。
    """
    try:
        _validate_requirement_dict(raw)
        req = _Requirement(**dict(raw))
    except _ConditionContractError as exc:
        raise HypothesisContractError(str(exc), dict(exc.detail)) from exc
    d = req.to_dict()
    for k in REQUIREMENT_BINDING_FIELDS:
        d[k] = ""
    return canonical_json(d)


def _hypothesis_id_from_payload(payload: dict) -> str:
    """从规范载荷推导 hypothesis_id(构造期同算法;不含
    hypothesis_id 字段本身)。"""
    d = {k: v for k, v in payload.items() if k != "hypothesis_id"}
    req_sigs = sorted(_requirement_identity_signature(r)
                      for r in (d.get("requirements") or []))
    return stable_id(
        "hyp", str(d.get("parent_path_id", "")),
        str(d.get("substrate_state_ref", "")),
        canonical_json(d.get("participants") or []),
        str(d.get("transformation_ref", "")),
        str(d.get("participant_list_status", "")),
        str(d.get("step_scope", "")),
        str(d.get("origin_group_key", "")),
        canonical_json(req_sigs),
        canonical_json(sorted(str(x) for x in (d.get("assumptions") or []))),
        canonical_json(sorted(str(x)
                              for x in (d.get("dependency_refs") or []))))


def _reject_foreign_requirement_bindings(raw_requirements: list,
                                         hypothesis_id: str) -> None:
    """R3-06 外来绑定拒绝:任一要求带非空绑定字段而 introduced_edge
    ≠ 本假设 id(属于另一旧边/根上下文)⇒ 结构化拒绝;自绑定
    (introduced_edge == 本假设 id)允许(归零存档)。"""
    for i, raw in enumerate(raw_requirements):
        bindings = {k: str(raw.get(k, "") or "")
                    for k in REQUIREMENT_BINDING_FIELDS}
        if not any(bindings.values()):
            continue
        if bindings["introduced_edge"] != hypothesis_id:
            raise HypothesisContractError(
                "假设 requirements 携带外来引入绑定(introduced_* 属于"
                "另一旧边/上下文,不得冒称本候选要求的出处;新要求的"
                "评估绑定由上下文/审计按当前作用域完成)",
                {"kind": "foreign_requirement_binding",
                 "requirement_index": i,
                 "introduced_phase_id": bindings["introduced_phase_id"],
                 "introduced_scenario_ref":
                     bindings["introduced_scenario_ref"],
                 "introduced_edge": bindings["introduced_edge"],
                 "hypothesis_id": hypothesis_id})


def canonical_hypothesis_payload(hypothesis_dict: dict) -> dict:
    """规范化假设载荷(R3-08 契约:排序幂等下半套)。

    - requirements 按每条的 canonical_json 排序(顺序无关);
    - assumptions / dependency_refs 排序;
    - 其余字段原样(浅结构新容器,不修改输入;requirements 逐条
      深拷贝,调用方可持有)。
    hypothesis.to_dict() 输出此规范形;hypothesis_id 的身份哈希也
    基于此规范形——同语义不同顺序 ⇒ 同 id 且同 payload(第二次
    put 语义比较不因顺序报冲突)。
    """
    if not isinstance(hypothesis_dict, dict):
        raise HypothesisContractError(
            f"假设载荷必须是 dict:{type(hypothesis_dict).__name__}",
            {"kind": "invalid_hypothesis_payload_type",
             "got": type(hypothesis_dict).__name__})
    out = dict(hypothesis_dict)
    raw_reqs = out.get("requirements")
    if raw_reqs is None:
        raw_reqs = []
    if not isinstance(raw_reqs, (list, tuple)):
        raise HypothesisContractError(
            f"requirements 必须是列表:{type(raw_reqs).__name__}",
            {"kind": "invalid_requirements_type"})
    reqs = []
    for i, item in enumerate(raw_reqs):
        if not isinstance(item, dict):
            raise HypothesisContractError(
                f"假设要求必须是 dict:{type(item).__name__}",
                {"kind": "requirement_object_not_supported",
                 "requirement_index": i,
                 "got": type(item).__name__})
        reqs.append(copy.deepcopy(dict(item)))
    try:
        out["requirements"] = sorted(reqs, key=canonical_json)
    except TypeError as exc:
        raise HypothesisContractError(
            f"要求载荷不可规范化(JSON 不可序列化):{exc}",
            {"kind": "requirement_not_canonicalizable"}) from exc
    for field_name, kind in (("assumptions", "invalid_assumptions_type"),
                             ("dependency_refs",
                              "invalid_dependency_refs_type")):
        items = out.get(field_name)
        if items is None:
            items = []
        if not isinstance(items, (list, tuple)) or not all(
                isinstance(x, str) for x in items):
            raise HypothesisContractError(
                f"{field_name} 必须是字符串列表:{items!r}",
                {"kind": kind, "field": field_name})
        out[field_name] = sorted(items)
    return out


def recompute_hypothesis_id(hypothesis_dict: dict) -> str:
    """从载荷重推导 hypothesis_id(R3-08 契约;存储线 submit 复核用)。

    与构造期同算法:先 canonical_hypothesis_payload 归一(排序),
    再按要求身份签名(绑定字段归零)推导 id;外来绑定与构造期同样
    结构化拒绝(kind=foreign_requirement_binding)。输入含不含
    hypothesis_id 字段均可(该字段不参与推导)。
    """
    payload = canonical_hypothesis_payload(dict(hypothesis_dict))
    hid = _hypothesis_id_from_payload(payload)
    _reject_foreign_requirement_bindings(
        list(payload.get("requirements") or []), hid)
    return hid


def build_hypothesis(
    *,
    parent_path_id: str,
    substrate_state_ref: str,
    participants: list[Participant],
    participant_list_status: str,
    step_scope: str,
    transformation_ref: str = "",
    transformation_signature_status: str = "unknown",
    step_scope_evidence_refs: list[str] | None = None,
    provenance_refs: list[str] | None = None,
    support_group_refs: list[str] | None = None,
    requirements: list[dict] | None = None,
    assumptions: list[str] | None = None,
    dependency_refs: list[str] | None = None,
    audit_ref: str = "",
    model_decision_ref: str = "",
    legacy_relationship_status: str = "",
    origin_group_key: str = "",
) -> ReactionHypothesis:
    """构造反应假设(参与物先过 H02/H03 契约与归并)。

    hypothesis_id = 冻结反应语义哈希(父路径 + 底物状态 + 参与物规范化 +
    转化引用 + 参与物列表状态 + step_scope + 来源组键 + **科学前提**
    (requirements 全语义/顺序无关/绑定归零、assumptions、
    dependency_refs,R2-07/R3-08))。origin_group_key 是调用方给的
    来源组指纹(如同一供体记录);不同来源组键默认不合并(无法确认
    等价时不强制合并)。

    R3-08 构造校验(fail-closed,绝无裸 TypeError):
    - requirements 元素必须是 dict(Requirement 对象不受支持 ⇒
      HypothesisContractError(kind=requirement_object_not_supported));
    - 逐条过 path_context.validate_requirement_dict(level/value 必填、
      level 枚举、区间 lo ≤ hi、已知条件键、来源/绑定字段类型),
      ConditionContractError 统一转 HypothesisContractError(detail 保留);
    - requirements dicts 深拷贝规范化(绑定字段归零、按 canonical_json
      排序):caller-owned dict 后续修改不影响假设;
    - 外来引入绑定(属于另一旧边)⇒ HypothesisContractError(kind=
      foreign_requirement_binding);自绑定(本假设 id)允许(R3-06)。
    """
    if not participants:
        raise HypothesisContractError(
            "反应假设至少需要一个参与物", {"parent_path_id": parent_path_id})
    if participant_list_status not in PARTICIPANT_LIST_STATUSES:
        raise HypothesisContractError(
            f"participant_list_status 非法:{participant_list_status!r}",
            {"participant_list_status": participant_list_status})
    if step_scope not in STEP_SCOPES:
        raise HypothesisContractError(
            f"step_scope 非法:{step_scope!r}", {"step_scope": step_scope})
    # 底物锚点(F07):substrate_state_ref 必须是本假设的 reactant 侧
    # primary_substrate 参与物 —— 引用不属于反应物锚点的状态属于
    # 结构性违约,不能构造后又被审计为"全核实"
    anchor_ok = any(
        p.side == PARTICIPANT_SIDE_REACTANT
        and p.role == PARTICIPANT_ROLE_PRIMARY_SUBSTRATE
        and p.state_ref == substrate_state_ref
        for p in participants)
    if not anchor_ok:
        raise HypothesisContractError(
            "substrate_state_ref 不是本假设的 reactant 侧 primary_"
            "substrate 参与物(底物锚点违约)",
            {"kind": "substrate_anchor_violation",
             "substrate_state_ref": substrate_state_ref,
             "parent_path_id": parent_path_id})
    normalized, ambiguous = normalize_participants(list(participants))
    if participant_list_status in (
            PARTICIPANT_LIST_SOURCE_COMPLETE, PARTICIPANT_LIST_DECLARED_COMPLETE
    ) and not any(
            p.side == PARTICIPANT_SIDE_PRODUCT for p in normalized):
        raise HypothesisContractError(
            "完整声明的假设必须至少有一个产物侧参与物",
            {"parent_path_id": parent_path_id})
    # R3-08:requirements 完整构造校验 + 深拷贝规范化(绑定归零)
    raw_requirements = list(requirements or [])
    normalized_reqs: list[dict] = []
    for i, raw in enumerate(raw_requirements):
        if not isinstance(raw, dict):
            raise HypothesisContractError(
                f"假设要求必须是 dict:{type(raw).__name__}"
                "(Requirement 对象不受支持;请传 to_dict() 后的字典)",
                {"kind": "requirement_object_not_supported",
                 "requirement_index": i,
                 "got": type(raw).__name__})
        try:
            _validate_requirement_dict(
                raw, where={"requirement_index": i})
            req = _Requirement(**dict(raw))
        except _ConditionContractError as exc:
            raise HypothesisContractError(
                str(exc), dict(exc.detail)) from exc
        d = req.to_dict()          # 规范形(value_basis 推断/字段补全)
        for k in REQUIREMENT_BINDING_FIELDS:
            d[k] = ""              # 绑定出处归上下文层,不进假设载荷
        normalized_reqs.append(d)
    normalized_reqs.sort(key=canonical_json)   # 排序归一(顺序无关)
    # R2-07/R3-08:科学前提入身份 —— requirements(essential/preference
    # 全语义,顺序无关,绑定归零)、assumptions、dependency_refs 均影响
    # 假设语义:同父/同结构/同来源但要求有氧/无氧/带未解决依赖是三个
    # 不同假设,可共存落账;相同语义重放 ⇒ 同 id 幂等(同 payload)。
    payload = {
        "schema_version": PPV1_HYPOTHESIS_SCHEMA_VERSION,
        "parent_path_id": parent_path_id,
        "substrate_state_ref": substrate_state_ref,
        "participants": [p.to_dict() for p in normalized],
        "participant_list_status": participant_list_status,
        "step_scope": step_scope,
        "transformation_ref": transformation_ref,
        "transformation_signature_status": transformation_signature_status,
        "step_scope_evidence_refs": list(step_scope_evidence_refs or []),
        "provenance_refs": list(provenance_refs or []),
        "support_group_refs": list(support_group_refs or []),
        "requirements": normalized_reqs,
        "assumptions": list(assumptions or []),
        "dependency_refs": list(dependency_refs or []),
        "audit_ref": audit_ref,
        "model_decision_ref": model_decision_ref,
        "legacy_relationship_status": legacy_relationship_status,
        "ambiguous_participants": ambiguous,
        "origin_group_key": origin_group_key,
    }
    hypothesis_id = _hypothesis_id_from_payload(payload)
    # R3-06:外来绑定结构化拒绝(自绑定 == 本 id 允许,已归零存档)
    _reject_foreign_requirement_bindings(raw_requirements, hypothesis_id)
    return ReactionHypothesis(
        hypothesis_id=hypothesis_id,
        parent_path_id=parent_path_id,
        substrate_state_ref=substrate_state_ref,
        participants=normalized,
        participant_list_status=participant_list_status,
        step_scope=step_scope,
        transformation_ref=transformation_ref,
        transformation_signature_status=transformation_signature_status,
        step_scope_evidence_refs=list(step_scope_evidence_refs or []),
        provenance_refs=list(provenance_refs or []),
        support_group_refs=list(support_group_refs or []),
        requirements=[_freeze_requirement_dict(d)
                      for d in normalized_reqs],
        assumptions=list(assumptions or []),
        dependency_refs=list(dependency_refs or []),
        audit_ref=audit_ref,
        model_decision_ref=model_decision_ref,
        legacy_relationship_status=legacy_relationship_status,
        ambiguous_participants=ambiguous,
        origin_group_key=origin_group_key,
    )
